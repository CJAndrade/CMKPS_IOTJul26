import random  # Used for generating mock data. Replace with real sensor libs.
from flask import Flask, jsonify, render_template

app = Flask(__name__)


def read_sensor_data():
    """Simulates reading from a physical sensor.

    Replace this logic with actual hardware libraries (e.g., DHT22, BMP280).
    """
    temperature = round(random.uniform(20.0, 30.0), 2)
    humidity = round(random.uniform(40.0, 60.0), 2)
    return {"temperature": temperature, "humidity": humidity}


@app.route("/")
def index():
    """Renders the main dashboard webpage."""
    return render_template("index.html")


@app.route("/api/sensor")
def get_sensor_data():
    """API endpoint providing real-time data in JSON format."""
    data = read_sensor_data()
    return jsonify(data)


if __name__ == "__main__":
    # host='0.0.0.0' allows external devices on the local network to view the page
    app.run(debug=True, host="0.0.0.0", port=5000)
